from metaworld.envs.mujoco.env_dict import (ALL_V2_ENVIRONMENTS_GOAL_HIDDEN,
                                            ALL_V2_ENVIRONMENTS_GOAL_OBSERVABLE
                                            )

__all__ = ['ALL_V2_ENVIRONMENTS_GOAL_HIDDEN',
           'ALL_V2_ENVIRONMENTS_GOAL_OBSERVABLE']